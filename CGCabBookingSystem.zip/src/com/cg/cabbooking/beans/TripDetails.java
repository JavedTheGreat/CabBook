package com.cg.cabbooking.beans;

public class TripDetails {
	public int fare;
	private String tripId;

	public TripDetails(int source, int destination) {
		// TODO Auto-generated constructor stub
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	/*public int getSource() {
		return source;
	}
	public void setSource(int source) {
		this.source = source;
	}
	public int getDestination() {
		return destination;
	}
	public void setDestination(int destination) {
		this.destination = destination;
	}*/
	public String getTripId() {
		return tripId;
	}
	public void setTripId(String tripId) {
		this.tripId = tripId;
	}
}