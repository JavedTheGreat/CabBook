package com.cg.cabbooking.beans;

public class UserDetails {

	private String firstName;
	private String lastName;
	private String emailId;
	TripDetails tripDetails;
	private int customerId;
	private long phoneNumber;
	public UserDetails(String firstName, String lastName, String emailId, TripDetails tripDetails, int customerId,
			long phoneNumber) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.tripDetails = tripDetails;
		this.customerId = customerId;
		this.phoneNumber = phoneNumber;
	}
	public UserDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public TripDetails getTripDetails() {
		return tripDetails;
	}
	public void setTripDetails(TripDetails tripDetails) {
		this.tripDetails = tripDetails;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
}