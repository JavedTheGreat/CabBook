package com.cg.cabbooking.util;

import java.util.HashMap;
import java.util.Random;

import com.cg.cabbooking.beans.UserDetails;

public class CabBookingDBUtil {
	public static HashMap<Long,UserDetails> userDetails = new HashMap<>();
	private static int tripID = 100;
	static Random customerId = new Random();
	static Random tripId = new Random();
//	public static int customerID=customerId.nextInt(9999)%n;
//
//	public static int getCUSTOMER_ID() {
//		return ++customerID;
//	}
	public static int getTRIP_ID() {
		return ++tripID;
	}
}