package com.cg.cabbooking.client;

import java.util.Scanner;
import com.cg.cabbooking.exceptions.InvalidChoiceException;
import com.cg.cabbooking.exceptions.InvalidPhoneNumberException;
import com.cg.cabbooking.exceptions.LocationNotFoundException;
import com.cg.cabbooking.exceptions.TripNotFoundException;
import com.cg.cabbooking.services.CabBookingService;
import com.cg.cabbooking.services.CabBookingServiceImpl;

public class MainClass {
	static Scanner sc= new Scanner(System.in);
	static CabBookingService service = new CabBookingServiceImpl();
	public static void main(String[] args) throws InvalidChoiceException, InvalidPhoneNumberException, LocationNotFoundException, TripNotFoundException{
		mainScreen();
		int userChoice = sc.nextInt();
		startMenu(userChoice);
	}
	public static void startMenu(int userChoice) throws InvalidChoiceException, InvalidPhoneNumberException, LocationNotFoundException, TripNotFoundException{
		switch(userChoice) {
		case 1:	System.out.println("Enter your corresponding details");
						System.out.println("First Name: ");
						String firstName=sc.next();
						System.out.println("Last Name: ");
						String lastName=sc.next();
						System.out.println("Phone Number: ");
						long phoneNumber=sc.nextLong();
						System.out.println("Email: ");
						String emailId=sc.next();
						break;
		case 2:	locationsList();
						System.out.println("Enter your pick up location ");		
						int source = sc.nextInt();
						locationsList();
						System.out.println("Enter your drop location");
						int destination = sc.nextInt();
						System.out.println(service.bookCab(source, destination));
						//implement functions
						break;
		case 3:	locationsList();
						System.out.println("Enter your pick up location ");		
						source = sc.nextInt();
						locationsList();
						System.out.println("Enter your drop location");
						destination = sc.nextInt();
						System.out.println("Total fare for the requested trip is: ");
						System.out.println(service.getFareEstimate(source, destination));
						break;
		case 4:	System.out.println("Enter your desired tripId: ");
						String tripId = sc.next();
						//implement functions
						break;
		case 5:	System.out.println("Enter your customerId to retrieve all previous trip details: ");
						int customerId = sc.nextInt();
						//implement functions
						break;
		default:
						System.out.println("Invalid choice, please try again.");
		}
		System.out.println("What do you want to do now ?");
		System.out.println("1. Continue");
		System.out.println("2. Exit");
		int choice =sc.nextInt();
		if(choice==2)
			System.exit(0);
		main(null);
	}
	public static void mainScreen(){
		System.out.println("--------Welcome to Cab Booking System!--------");
		System.out.println("Please enter your choice: ");
		System.out.println("1. Create an account");
		System.out.println("2. New trip booking");
		System.out.println("3. Fare estimation");
		System.out.println("4. Specific trip detail");
		System.out.println("5. All trip details");
	}
	public static void locationsList() {
		System.out.println("1: Capgemini Phase 3\t2: Quadron Phase 2\t3: Infosys Circle\t4: Hinjewadi Chauk\t5: Wakad");
	}
}