package com.cg.cabbooking.services;

import com.cg.cabbooking.beans.TripDetails;
import com.cg.cabbooking.exceptions.InvalidChoiceException;

public interface CabBookingService {
	int getFareEstimate(int source, int destination);

	//int acceptUserDetails(String firstName, String lastName, long phoneNumber, String emailId);
	String bookCab(int source , int destination);
	//int acceptUserDetails(String firstName, String lastName, long phoneNumber, String emailId, int source,
//			int destination);
}