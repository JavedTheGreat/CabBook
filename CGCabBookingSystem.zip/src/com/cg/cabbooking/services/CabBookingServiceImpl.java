package com.cg.cabbooking.services;

import com.cg.cabbooking.exceptions.InvalidChoiceException;
import com.cg.cabbooking.util.CabBookingDBUtil;
import com.cg.cabbookingdaoservices.TripDetailsDAO;
import com.cg.cabbookingdaoservices.TripDetailsDAOImpl;
import com.cg.cabbooking.beans.*;

public class CabBookingServiceImpl implements CabBookingService{
	TripDetailsDAO service = new TripDetailsDAOImpl();
	TripDetails tripDetails;
	
	@Override
	public String bookCab(int source , int destination)
	{
		TripDetails trip = new TripDetails(source, destination);
		trip = service.save(trip);
		String s= " Trip booked " +  CabBookingDBUtil.getTRIP_ID();
		return s;
	}
	@Override
	public int getFareEstimate(int source, int destination) {
		int fareEstimate;
		if (source<destination)
			//if (source > 10)
				//throw new InvalidChoiceException().getMessage("Enter a valid location");
			fareEstimate=(destination-source)*7;
		else
			fareEstimate=(source-destination)*7;
		return fareEstimate;
	}
}