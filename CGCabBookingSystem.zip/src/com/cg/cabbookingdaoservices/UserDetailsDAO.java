package com.cg.cabbookingdaoservices;

public interface UserDetailsDAO {

}
