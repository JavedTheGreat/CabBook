package com.cg.cabbookingdaoservices;

import java.util.List;
import com.cg.cabbooking.beans.TripDetails;
import com.cg.cabbooking.beans.UserDetails;

public interface TripDetailsDAO {
	TripDetails save(UserDetails userDetails);
	boolean update(TripDetails account);
	TripDetails findOne(String tripId);
	List<TripDetails> findAll();
	TripDetails save(TripDetails userDetails);
}