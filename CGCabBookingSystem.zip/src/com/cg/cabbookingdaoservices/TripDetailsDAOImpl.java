package com.cg.cabbookingdaoservices;

import java.util.List;

import com.cg.cabbooking.beans.TripDetails;
import com.cg.cabbooking.beans.UserDetails;

public class TripDetailsDAOImpl implements TripDetailsDAO{

	@Override
	public TripDetails save(TripDetails userDetails) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean update(TripDetails account) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public TripDetails findOne(String tripId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<TripDetails> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TripDetails save(UserDetails userDetails) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public TripDetails save(UserDetails userDetails) {
//		TripDetails t= new TripDetails(source, destination);
//		return  ;
//	}

}
